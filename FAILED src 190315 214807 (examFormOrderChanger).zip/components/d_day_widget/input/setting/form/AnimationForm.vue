<template>
  <div class="inputForm">
    <div class="inputLine">
      <label>Type: </label>
      <select
        :value="animationType"
        @change="updateAnimation($event, 'animationType')"
      >
        <option
          v-for="(animationType, index) in animationTypes"
          :value="animationType"
          :key="index"
        >
          {{ animationType }}
        </option>
      </select>
    </div>

    <div class="inputLine">
      <label>Transition: </label>
      <input
        type="number"
        min="0.1"
        step="0.1"
        :value="animationTransition"
        @change="updateAnimation($event, 'animationTransition')"
        placeholder="날짜 전환에 드는 시간을 입력해주세요."
      /><span>&nbsp;sec</span>
    </div>

    <div class="inputLine">
      <label>Interval: </label>
      <input
        type="number"
        min="0.1"
        step="0.1"
        :value="animationInterval"
        @change="updateAnimation($event, 'animationInterval')"
        placeholder="날짜 전환 주기를 입력해주세요."
      /><span>&nbsp;sec</span>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex"

export default {
  name: "AnimationForm",
  methods: {
    updateAnimation(event, attr) {
      this.$store.dispatch("animations/updateAnimation", {
        attr: attr,
        value: event.target.value,
      })
    },
  },
  computed: mapState("animations", [
    "animationType",
    "animationTransition",
    "animationInterval",
    "animationTypes",
  ]),
}
</script>

<style scoped></style>
