<template>
  <div>
    <div class="inputForm">
      <div class="examFormBtns">
        <span class="removeBtn">
          <button @click="removeExam">-</button>
        </span>

        <slot> Insert orderChangeBtns here </slot>
      </div>

      <div class="inputLine">
        <label>Title: </label>
        <input
          type="text"
          :value="getExamTitleByIndex(examFormIndex)"
          @change="updateExam($event, 'examTitle')"
          placeholder="시험명을 입력해주세요."
        />
      </div>

      <div class="inputLine">
        <label>Date: </label>
        <input
          type="date"
          :value="getExamDateByIndex(examFormIndex)"
          @change="updateExam($event, 'examDate')"
        />
      </div>
    </div>
    <br />
  </div>
</template>

<script>
import "@/assets/css/d_day_widget/ExamForm.css"
import { mapGetters } from "vuex"

export default {
  name: "ExamForm",
  props: {
    examFormIndex: {
      type: Number,
      default: 9999,
    },
    examId: {
      type: Number,
      default: 9999,
    },
  },
  methods: {
    updateExam(event, attr) {
      this.$store.dispatch("exams/updateExam", {
        examFormIndex: this.examFormIndex,
        attr: attr,
        value: event.target.value,
      })
    },

    removeExam() {
      this.$store.dispatch("exams/removeExam", this.examFormIndex)
    },
  },
  computed: mapGetters("exams", ["getExamTitleByIndex", "getExamDateByIndex"]),
}
</script>
