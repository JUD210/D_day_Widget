<template>
  <BaseToggleBox title="Exams">
    <div v-for="(exam, index) in exams" :key="exam.id">
      <ExamForm :examFormIndex="index" :examId="exam.id">
        <span class="orderChangeBtn">
          <button v-if="exams[index - 1]" @click="changeExamOrder(index, 'up')">
            ↑
          </button>
          <button
            v-if="exams[index + 1]"
            @click="changeExamOrder(index, 'down')"
          >
            ↓
          </button>
        </span>
      </ExamForm>
    </div>

    <button @click="addExam">+</button>
  </BaseToggleBox>
</template>

<script>
import ExamForm from "@/components/d_day_widget/input/setting/form/ExamForm.vue"
import { mapState, mapActions } from "vuex"

export default {
  name: "ExamsSetting",
  components: {
    ExamForm,
  },
  methods: {
    changeExamOrder(index, cmd) {
      this.$store.dispatch("exams/changeExamOrder", {
        index: index,
        cmd: cmd,
      })
    },
    ...mapActions("exams", ["addExam"]),
  },
  computed: { ...mapState("exams", ["exams"]) },
}
</script>
