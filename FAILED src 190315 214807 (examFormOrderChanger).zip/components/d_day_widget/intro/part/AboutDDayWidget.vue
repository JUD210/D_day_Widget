<template>
  <div class="about_d_day_widget">
    <h2>D-day 위젯이란?</h2>

    <p>
      각종 시험 D-day를 간편하게 편집하여 캠(ManyCam) 또는 방송
      프로그램(OBS/Xsplit) 화면에 띄울 수 있는 위젯입니다.<br />
      캠스터디를 하며 열공하시는 여러분을 위해 만들어졌으며, 평생 완전
      무료입니다!<br /><br />
      DB를 제외한 모든 소스는 GitHub에 공개되어 있습니다.<br />
    </p>

    <ul>
      <li>
        <a href="https://github.com/JUD210/D_day_Widget"
          >[ GitHub ]&nbsp; D_day_Widget</a
        >
      </li>
    </ul>

    <p>여러분의 피드백/건의는 언제나 환영합니다. 😄<br /></p>

    <ul>
      <li>
        <a
          href="https://www.youtube.com/channel/UCYPWzViA-uq9sBop7ssYaEg?sub_confirmation=1"
        >
          [ YouTube ]&nbsp; Study with Hyeogikarp (잉혁킹)
        </a>
      </li>
      <li>[ E-mail ]&nbsp; judicious210@gmail.com</li>
    </ul>
  </div>
</template>

<script>
export default {}
</script>
