export const namespaced = true

const d = new Date()
let date = ""
if (d.getUTCMonth() + 1 < 10) {
  date += `${d.getUTCFullYear()}-0${d.getUTCMonth() + 1}-${d.getUTCDate()}`
} else {
  date += `${d.getUTCFullYear()}-${d.getUTCMonth() + 1}-${d.getUTCDate()}`
}

export const state = {
  id: 100,

  exams: [
    {
      id: 100,
      examTitle: "시험명",
      examDate: date,
    },
  ],
}

export const mutations = {
  ADD_EXAM(state) {
    state.exams.push({ id: state.id, examTitle: null, examDate: date })
  },
  UPDATE_EXAM(state, { index, attr, value }) {
    state.exams[index][attr] = value
  },
  REMOVE_EXAM(state, examFormIndex) {
    state.exams.splice(examFormIndex, 1)
  },

  RESET_EXAMS(state, examsObject) {
    state.exams = examsObject
  },

  CHANGE_EXAM_ORDER(state, { index, cmd }) {
    if (cmd == "up") {
      console.log(index);
      console.log(state.exams[index - 1].id)
      console.log(state.exams[index].id)

      let tmp = state.exams[index - 1].id
      state.exams[index - 1].id = state.exams[index].id
      state.exams[index].id = tmp

      console.log(state.exams[index - 1].id)
      console.log(state.exams[index].id)
      console.log(state.exams);
    } else if (cmd == "down") {
      let tmp = state.exams[index + 1].id
      state.exams[index + 1].id = state.exams[index].id
      state.exams[index].id = tmp
    }
  },
}

export const actions = {
  addExam({ commit, state }) {
    state.id += 1
    commit("ADD_EXAM")

    console.log(`exams/ADD_EXAM
    state.exams.push({ id: ${state.id}, examTitle: null, examDate: ${date} })`)
  },
  updateExam({ commit }, { index, attr, value }) {
    commit("UPDATE_EXAM", { index, attr, value })

    console.log(`exams/UPDATE_EXAM
    state.exams[${index}][${attr}] = ${value}`)
  },
  removeExam({ commit }, examFormIndex) {
    commit("REMOVE_EXAM", examFormIndex)

    console.log(`exams/REMOVE_EXAM
    state.exams.splice(${examFormIndex}, 1)`)
  },

  resetExams({ commit }, examsObject) {
    commit("RESET_EXAMS", examsObject)

    console.log(`exams/RESET_EXAMS
    state.exams = ${JSON.stringify(examsObject)}`)
  },

  changeExamOrder({ commit }, { index, cmd }) {
    commit("CHANGE_EXAM_ORDER", { index, cmd })

    // console.log(`exams/CHANGE_EXAM_ORDER
    // state.exams[${index - 1}] = state.exams[${index}]}
    // state.exams[${index}] = state.exams[${index - 1}]}`)
  },
}

export const getters = {
  getExamTitleByIndex: state => index => {
    return state.exams[index].examTitle
  },
  getExamDateByIndex: state => index => {
    return state.exams[index].examDate
  },
}
