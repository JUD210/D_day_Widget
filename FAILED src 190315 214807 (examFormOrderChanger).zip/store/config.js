module.exports = {
  apiKey: "AIzaSyAk2R8PNMQTVxxTbVhSI3llhAo0Esq2FoE",
  authDomain: "gongbanghelper.firebaseapp.com",
  databaseURL: "https://gongbanghelper.firebaseio.com",
  projectId: "gongbanghelper",
  storageBucket: "gongbanghelper.appspot.com",
  messagingSenderId: "1001295845112",

  // apiKey: "AIzaSyBcgIXzSEEOZ2Zjgj0U0hvG_Dy6VVCPqgs",
  // authDomain: "dday-test.firebaseapp.com",
  // databaseURL: "https://dday-test.firebaseio.com/",
  // projectId: "dday-test",
  // storageBucket: "dday-test.appspot.com",
  // messagingSenderId: "864965012920",
}
